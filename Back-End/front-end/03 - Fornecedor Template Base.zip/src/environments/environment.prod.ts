export const environment = {
  production: true,
  apiUrlv1: 'https://localhost:5003/api/v1/'
};
