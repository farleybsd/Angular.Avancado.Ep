import { Component } from '@angular/core';

@Component({
  selector: 'conta-app-root',
  template: '<router-outlet></router-outlet>'
})
export class ContaAppComponent { }
